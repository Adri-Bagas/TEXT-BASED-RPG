<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CharaClassController extends Controller
{
    //
}
