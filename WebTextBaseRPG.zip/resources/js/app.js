import './bootstrap';
import anime from 'animejs';
import jQuery from 'jquery';
window.$ = jQuery;
window.anime = anime;