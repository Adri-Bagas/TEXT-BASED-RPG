

<?php $__env->startSection('cssTambahan'); ?>
    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('')); ?>vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsTambahan'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('')); ?>vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('')); ?>vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('')); ?>js/demo/datatables-demo.js"></script>

    <script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Class Table</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Class</h6>
    </div>
    <div class="card-body">
        <div class="" style="width: 30%;">
            <form action="<?php echo e(url('admin/dash/start-scene/add')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="">Race</label>
                    <select class="form-control" name="races_id" id="">
                        <?php $__currentLoopData = $races; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $race): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($race->id); ?>"><?php echo e($race->id); ?> - <?php echo e($race->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="">Story Text</label>
                    <textarea class="form-control" name="story_text" id="" rows="3"></textarea>
                </div>

                <div class="form-group">
                    <label for="">Choice</label>
                    <input type="text" class="form-control" name="choice" id="" aria-describedby="helpId" placeholder="">
                </div>

                <?php if($errors->any()): ?>
                <p style="color:red;"><?php echo e($errors->first()); ?></p>
                <?php else: ?>
                <?php endif; ?>

                <button type="reset" class="btn btn-warning p-2 w-25">Reset</button>

                <button type="submit" class="btn btn-primary ml-2 p-2  w-25">Submit</button>
            </form>
        </div>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebTextBaseRPG\resources\views/admin/forms/startSceneAdd.blade.php ENDPATH**/ ?>