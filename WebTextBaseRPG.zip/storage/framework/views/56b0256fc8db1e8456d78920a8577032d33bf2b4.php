<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <style>
        @font-face {
            font-family: Alagard;
            src: url(<?php echo e(asset('font/Alagard.ttf')); ?>);
        }

        @font-face {
            font-family: Bleo;
            src: url(<?php echo e(asset('font/Bleo.ttf')); ?>);
        }

        @font-face {
            font-family: KiwiSoda;
            src: url(<?php echo e(asset('font/KiwiSoda.ttf')); ?>);
        }

        @font-face {
            font-family: PerfectDos;
            src: url(<?php echo e(asset('font/PerfectDosWin.ttf')); ?>);
        }

        @font-face {
            font-family: Alkhemikal;
            src: url(<?php echo e(asset('font/Alkhemikal.ttf')); ?>);
        }

        @font-face {
            font-family: VeniceClassic;
            src: url(<?php echo e(asset('font/VeniceClassic.ttf')); ?>);
        }
        </style>
    <?php echo $__env->yieldContent('css'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>

    <?php echo $__env->yieldContent('content'); ?>
</body>

<?php echo $__env->yieldContent('js'); ?>

</html><?php /**PATH D:\WebTextBaseRPG\resources\views/layouts/home.blade.php ENDPATH**/ ?>