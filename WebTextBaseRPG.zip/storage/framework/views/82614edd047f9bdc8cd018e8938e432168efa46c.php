

<?php $__env->startSection('cssTambahan'); ?>
    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('')); ?>vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsTambahan'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('')); ?>vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('')); ?>vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('')); ?>js/demo/datatables-demo.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Class Table</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Class</h6>
    </div>
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
    <?php endif; ?>
    <div class="card-body">
        <a href="" class="btn btn-info mb-4">RESTORE ALL</a>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Health Boost</th>
                        <th>Mana Boost</th>
                        <th>CHA Boost</th>
                        <th>Icon</th>
                        <th>User Count</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Name</th>
                        <th>Health Boost</th>
                        <th>Mana Boost</th>
                        <th>Char Boost</th>
                        <th>Icon</th>
                        <th>User Count</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
                <tbody>
                <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->name); ?></td>
                        <td><?php echo e($data->health_boost); ?></td>
                        <td><?php echo e($data->mana_boost); ?></td>
                        <td><?php echo e($data->char_boost); ?></td>
                        <td><img src="<?php echo e($data->media->first() ? $data->media->first()->getUrl() : ''); ?>" alt=""></td>
                        <td><?php echo e($data->userChara->count()); ?></td>
                        <td>
                            <a href="" class="btn btn-primary">RESTORE</a>
                        </td>
                    </tr>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebTextBaseRPG\resources\views/admin/trashed/classTrashed.blade.php ENDPATH**/ ?>