

<?php $__env->startSection('cssTambahan'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('')); ?>vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/dropzone@5/dist/min/dropzone.min.css" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsTambahan'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('')); ?>vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('')); ?>vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('')); ?>js/demo/datatables-demo.js"></script>

    <script src="https://unpkg.com/dropzone@5/dist/min/dropzone.min.js"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Scenario Table</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Scenario</h6>
    </div>
    <div class="card-body">
        <div class="" style="width: 30%;">
            <form>
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="">Rarity</label>
                    <select class="form-control" name="rarity" id="">
                    <option disabled selected value> <?php echo e($data->rarity); ?> </option>
                </div>

                <div class="form-group">
                    <textarea class="form-control" name="story_text" id="" rows="3" readonly><?php echo e($data->story_text); ?></textarea>
                </div>

                <div id="satu1">
                <div class="form-group">
                    <label for="">Choice 1</label>
                    <input type="text" class="form-control" name="choice1" id="" aria-describedby="helpId" placeholder="" value="<?php echo e($data->choice1); ?>" readonly>
                </div>
                
                <div class="form-group">
                    <label for="">Response 1</label>
                    <textarea class="form-control" name="response1" id="" rows="3" required readonly><?php echo e($data->response1); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="">Requirements 1</label>
                    <select class="form-control" name="req1" id="cons1" required>
                    <option disabled selected value> <?php echo e($data->req1); ?> </option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="">Min Req 1</label>
                    <input type="number" name="min1" class="form-control" value="<?php echo e($data->min1); ?>" readonly>
                </div>
                
                <div class="form-group">
                    <label for="">Cons 1</label>
                    <select class="form-control" name="cons1" id="" required disabled>
                    <option disabled selected value><?php echo e($data->cons1); ?></option>
                    </select>
                </div>

                <div class="form-group" id="effect1">
                    <label for="">Effect 1</label>
                    <?php if($data->cons1 == 'ITEM'): ?>
                        <select name="" id="" disabled class="form-control">
                        <option disabled selected value><?php echo e($item1->id); ?> - <?php echo e($item1->name); ?></option>
                        </select>
                    <?php else: ?>
                        <input type="number" name="" id="" value="<?php echo e($data->effect1); ?>" readonly class="form-control">
                    <?php endif; ?>
                    
                </div>

                </div>


                <div id="second2">
                    <hr>
    
                    <div class="form-group" >
                        <label for="">Choice 2</label>
                        <input type="text" class="form-control" name="choice2" id="choice2" aria-describedby="helpId" placeholder="" value="<?php echo e($data->choice2); ?>" readonly>
                    </div>
    
                    <div class="form-group" >
                        <label for="">Response 2</label>
                        <textarea class="form-control" name="response2" id="" rows="3" readonly><?php echo e($data->repsonse2); ?></textarea>
                    </div>

                    <div class="form-group">
                    <label for="">Requirements 2</label>
                    <select class="form-control" name="req2" id="" disabled>
                    <option disabled selected value> <?php echo e($data->req2); ?> </option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="">Min Req 2</label>
                    <input type="number" name="min2" class="form-control" readonly value="<?php echo e($data->min2); ?>">
                </div>
    
                    <div class="form-group" >
                        <label for="">Cons 2</label>
                        <select class="form-control" name="cons2" id="cons2" disabled>
                        <option disabled selected value> <?php echo e($data->cons2); ?> </option>
                        </select>
                    </div>

    
                    <div class="form-group" id="effect2">
                        <label for="">Effect 2</label>
                        <?php if($data->cons2 == 'ITEM'): ?>
                        <select name="" id="" disabled class="form-control">
                        <option disabled selected value><?php echo e($item2->id); ?> - <?php echo e($item2->name); ?></option>
                        </select>
                        <?php else: ?>
                        <input type="number" name="" id="" value="<?php echo e($data->effect2); ?>" readonly class="form-control">
                        <?php endif; ?>
                    </div>
                </div>

                <div id="tiga3">

                    <hr>
    
                    <div class="form-group" >
                        <label for="">Choice 3</label>
                        <input type="text" class="form-control" name="choice3" id="" aria-describedby="helpId" placeholder="" readonly value="<?php echo e($data->choice3); ?>">
                    </div>
    
                    <div class="form-group" >
                        <label for="">Response 3</label>
                        <textarea class="form-control" name="response3" id="" rows="3" readonly><?php echo e($data->response3); ?></textarea>
                    </div>
                    <div class="form-group">
                    <label for="">Requirements 3</label>
                    <select class="form-control" name="req3" id="" disabled>
                    <option disabled selected value> <?php echo e($data->req3); ?> </option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="">Min Req 3</label>
                    <input type="number" name="min3" class="form-control" value="<?php echo e($data->min3); ?>" readonly>
                </div>
                    
                    <div class="form-group" >
                        <label for="">Cons 3</label>
                        <select class="form-control" name="cons3" id="cons3" disabled>
                        <option disabled selected value> <?php echo e($data->cons3); ?> </option>
                        </select>
                    </div>


    
                    <div class="form-group" id="effect3">
                        <label for="">Effect 3</label>
                        <?php if($data->cons3 == 'ITEM'): ?>
                        <select name="" id="" disabled>
                        <option disabled selected value class="form-control"><?php echo e($item3->id); ?> - <?php echo e($item3->name); ?></option>
                        </select>
                        <?php else: ?>
                        <input type="number" name="" id="" value="<?php echo e($data->effect3); ?>" readonly class="form-control">
                        <?php endif; ?>
                    </div>
                </div>

                <div id="empat4">
                    <hr>
    
                    <div class="form-group" >
                        <label for="">Choice 4</label>
                        <input type="text" class="form-control" name="choice4" id="" aria-describedby="helpId" placeholder="" readonly value="<?php echo e($data->choice4); ?>">
                    </div>
    
                    <div class="form-group" >
                        <label for="">Response 4</label>
                        <textarea class="form-control" name="response4" id="" rows="3" readonly><?php echo e($data->response4); ?></textarea>
                    </div>

                    <div class="form-group">
                    <label for="">Requirements 4</label>
                    <select class="form-control" name="req4" id="" disabled>
                    <option disabled selected value> <?php echo e($data->req4); ?> </option>
                    </select>
                </div>

                <div class="form-group">
                    <label for="">Min Req 4</label>
                    <input type="number" name="min4" class="form-control" readonly value="<?php echo e($data->min4); ?>">
                </div>
    
                    <div class="form-group" >
                        <label for="">Cons 4</label>
                        <select class="form-control" name="cons4" id="cons4" disabled>
                        <option disabled selected value> <?php echo e($data->cons4); ?> </option>
                        </select>
                    </div>
    
                    <div class="form-group" id="effect4">
                        <label for="">Effect 4</label>
                        <?php if($data->cons4 == 'ITEM'): ?>
                        <select name="" id="" disabled class="form-control">
                        <option disabled selected value><?php echo e($item4->id); ?> - <?php echo e($item4->name); ?></option>
                        </select>
                        <?php else: ?>
                        <input type="number" name="" id="" value="<?php echo e($data->effect4); ?>" readonly class="form-control">
                        <?php endif; ?>
                    </div>
                </div>

                <div>
                    <hr>

                    <div class="form-group">
                        <label for="">Failed Text</label>
                        <textarea class="form-control" name="failed_text" id="" rows="3" required readonly> <?php echo e($data->failed_text); ?> </textarea>
                    </div>

                    <div class="form-group" >
                        <label for="">Failed Cons</label>
                        <select class="form-control" name="failed_cons" id="failedCons" disabled>
                        <option disabled selected value> <?php echo e($data->failed_cons); ?> </option>
                        </select>
                    </div>

                    <div class="form-group" id="failedEff">
                        <label for="">Effect Failed</label>
                        <?php if($data->failed_cons == 'ITEM'): ?>
                        <select name="" id="" disabled class="form-control">
                        <option disabled selected value><?php echo e($item5->id); ?> - <?php echo e($item5->name); ?></option>
                        </select>
                        <?php else: ?>
                        <input type="number" name="" id="" value="<?php echo e($data->failed_eff); ?>" disabled class="form-control">
                        <?php endif; ?>
                    </div>
                </div>

                <?php if($errors->any()): ?>
                <p style="color:red;"><?php echo e($errors->first()); ?></p>
                <?php else: ?>
                <?php endif; ?>


            </form>
        </div>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebTextBaseRPG\resources\views/admin/details/scenarioDetail.blade.php ENDPATH**/ ?>