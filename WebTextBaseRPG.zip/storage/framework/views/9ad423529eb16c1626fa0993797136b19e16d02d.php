

<?php $__env->startSection('cssTambahan'); ?>
    <!-- Custom styles for this page -->
    <link href="<?php echo e(asset('')); ?>vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('jsTambahan'); ?>
    <!-- Page level plugins -->
    <script src="<?php echo e(asset('')); ?>vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="<?php echo e(asset('')); ?>vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="<?php echo e(asset('')); ?>js/demo/datatables-demo.js"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<div class="container-fluid">

<!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Starting Scenario Table</h1>

<!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Starting Scenario</h6>
    </div>
    <?php if(session()->has('message')): ?>
    <div class="alert alert-success">
        <?php echo e(session()->get('message')); ?>

    </div>
    <?php endif; ?>
    <div class="card-body">
        <a href="<?php echo e(url('admin/dash/start-scene/add')); ?>" class="btn btn-info mb-4">CREATE +</a>
        <a href="<?php echo e(url('admin/dash/start-scene/trashed')); ?>" class="btn btn-warning mb-4">TRASHED</a>
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Race</th>
                        <th>Story Text</th>
                        <th>Choice</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tfoot>
                    <tr>
                        <th>Race</th>
                        <th>Story Text</th>
                        <th>Choice</th>
                        <th>Action</th>
                    </tr>
                </tfoot>
                <tbody>
                    <?php $__currentLoopData = $datas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->races->name); ?></td>
                        <td><?php echo e($data->story_text); ?></td>
                        <td><?php echo e($data->choice); ?></td>
                        <td>
                            <a href="<?php echo e(url('admin/dash/start-scene/edit', $data->id)); ?>" class="btn btn-primary">EDIT</a> | 
                            <form action="<?php echo e(url('admin/start-scene/race', $data->id)); ?>" method="POST" style="display: inline-block">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn btn-warning">DELETE</button>
                            </form>
                        </td>
                    </tr>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebTextBaseRPG\resources\views/admin/tables/startScenesTable.blade.php ENDPATH**/ ?>