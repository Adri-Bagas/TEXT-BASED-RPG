<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/app.js'); ?>
    <style>
        @font-face {
            font-family: Alagard;
            src: url(<?php echo e(asset('font/Alagard.ttf')); ?>);
        }

        @font-face {
            font-family: Bleo;
            src: url(<?php echo e(asset('font/Bleo.ttf')); ?>);
        }

        @font-face {
            font-family: KiwiSoda;
            src: url(<?php echo e(asset('font/KiwiSoda.ttf')); ?>);
        }

        @font-face {
            font-family: PerfectDos;
            src: url(<?php echo e(asset('font/PerfectDosWin.ttf')); ?>);
        }

        @font-face {
            font-family: Alkhemikal;
            src: url(<?php echo e(asset('font/Alkhemikal.ttf')); ?>);
        }

        @font-face {
            font-family: VeniceClassic;
            src: url(<?php echo e(asset('font/VeniceClassic.ttf')); ?>);
        }
        </style>
    <link rel="stylesheet" href="<?php echo e(asset('style/home.css')); ?>">
    <title>Start Adventure.</title>
</head>
<body>
    <img class='background' src="<?php echo e(asset('img/gif/backgroundHome.gif')); ?>" alt="">

    <main>
        <div class="screen">
            <h1 class="hero-text">Start Your Adventure.</h1>
            <button class="btn1">Start !</button>

            <div class='signIn'>

            <h1 class="signText">Sign Up</h1>
                <form action="<?php echo e(route('register')); ?>" method="POST" id='signInForm'>
                    <?php echo csrf_field(); ?> 

                    <div class="formControl">
                        <label for="name">Name</label>
                        <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="name">

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="formControl">
                        <label for="email">Email</label>
                        <input type="text" id="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="formControl">
                        <label for="password">Password</label>
                        <input type="password" id="password" name="password" value="<?php echo e(old('password')); ?>" required autocomplete="new-password">

                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback" role="alert">
                            <strong><?php echo e($message); ?></strong>
                        </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="formControl">
                        <label for="password-confirm">Confirm Password</label>
                        <input type="password" id="password-confirm" name="password_confirmation" required autocomplete="new-password">
                    </div>

                    <div class="formControl2">
                        <input type="checkbox" name="agreed" id="agreed">
                        <label for="agreed">By Checking This You are agree to Our Terms And Condition in mind</label>
                    </div>

                    <button type="submit" class="btn2">Sign Up</button>
                </form>

                <p><a class="login">Already have an account?</a></p>
            </div>
        </div>
    </main>
    <div class="preloader">

    </div>
</body>

<script src="<?php echo e(asset('/js/home.js')); ?>"></script>

</html><?php /**PATH D:\WebTextBaseRPG\resources\views/auth/register.blade.php ENDPATH**/ ?>